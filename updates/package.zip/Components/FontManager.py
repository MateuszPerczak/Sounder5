from os.path import join,basename,splitext,exists
from os import environ,remove
from shutil import copy
from winreg import OpenKey,KEY_SET_VALUE,SetValueEx,HKEY_LOCAL_MACHINE,REG_SZ
from ctypes import wintypes,WinDLL,POINTER,c_wchar,byref,sizeof
class FontManager:
	def __init__(A):
		A.user32=WinDLL('user32',use_last_error=True);A.gdi32=WinDLL('gdi32',use_last_error=True)
		if not hasattr(wintypes,'LPDWORD'):wintypes.LPDWORD=POINTER(wintypes.DWORD)
		A.user32.SendMessageTimeoutW.restype=wintypes.LPVOID;A.user32.SendMessageTimeoutW.argtypes=wintypes.HWND,wintypes.UINT,wintypes.LPVOID,wintypes.LPVOID,wintypes.UINT,wintypes.UINT,wintypes.LPVOID;A.gdi32.AddFontResourceW.argtypes=wintypes.LPCWSTR,;A.gdi32.GetFontResourceInfoW.argtypes=wintypes.LPCWSTR,wintypes.LPDWORD,wintypes.LPVOID,wintypes.DWORD
	def install_font(A,path):
		E=path;B=join(environ['SystemRoot'],'Fonts',basename(E))
		if not exists(B):
			copy(E,B)
			if not A.gdi32.AddFontResourceW(B):remove(B);raise WindowsError('AddFontResource failed to load "%s"'%E)
			A.user32.SendMessageTimeoutW(65535,29,0,0,2,1000,None);C=basename(B);F=splitext(C)[0];D=wintypes.DWORD()
			if A.gdi32.GetFontResourceInfoW(C,byref(D),None,1):
				H=(c_wchar*D.value)()
				if A.gdi32.GetFontResourceInfoW(C,byref(D),H,1):F=H.value
			G=wintypes.BOOL();D.value=sizeof(G);A.gdi32.GetFontResourceInfoW(C,byref(D),byref(G),3)
			if G:F+=' (TrueType)'
			with OpenKey(HKEY_LOCAL_MACHINE,'Software\\Microsoft\\Windows NT\\CurrentVersion\\Fonts',0,KEY_SET_VALUE)as I:SetValueEx(I,F,0,REG_SZ,C)