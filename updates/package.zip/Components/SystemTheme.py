from winreg import OpenKey,HKEY_CURRENT_USER,KEY_READ,EnumValue
def get_theme():
	A='Dark'
	try:
		if EnumValue(OpenKey(HKEY_CURRENT_USER,'SOFTWARE\\\\Microsoft\\\\Windows\\\\CurrentVersion\\\\Themes\\\\Personalize\\\\',0,KEY_READ),2)[1]:return'Light'
		return A
	except Exception:return A