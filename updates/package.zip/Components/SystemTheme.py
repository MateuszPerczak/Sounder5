from darkdetect import theme
def get_theme():return theme()