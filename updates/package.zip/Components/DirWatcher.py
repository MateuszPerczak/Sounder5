import win32file,win32con
from time import sleep
from os.path import join,exists
class DirWatcher:
	def __init__(A,path,update_time):
		A.path=path;A.update_time=update_time
		if A.verify_path(A.path):A.init_watcher()
	def init_watcher(A):
		B=None;E=win32file.CreateFile(A.path,1,win32con.FILE_SHARE_READ|win32con.FILE_SHARE_WRITE|win32con.FILE_SHARE_DELETE,B,win32con.OPEN_EXISTING,win32con.FILE_FLAG_BACKUP_SEMANTICS,B)
		while True:
			for (D,C) in win32file.ReadDirectoryChangesW(E,1024,True,win32con.FILE_NOTIFY_CHANGE_FILE_NAME|win32con.FILE_NOTIFY_CHANGE_DIR_NAME|win32con.FILE_NOTIFY_CHANGE_ATTRIBUTES|win32con.FILE_NOTIFY_CHANGE_SIZE|win32con.FILE_NOTIFY_CHANGE_LAST_WRITE|win32con.FILE_NOTIFY_CHANGE_SECURITY,B,B):
				if C.endswith(('.mp3','.flac','.ogg')):
					if D==2:A.on_delete(join(A.path,C))
					elif D==1:A.on_add(join(A.path,C))
			sleep(A.update_time)
	def verify_path(A,path):return exists(path)
	'\n    Below methods that should be overwritten\n    '
	def on_delete(A,song):0
	def on_add(A,song):0