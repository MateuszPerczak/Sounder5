_E='playlist'
_D='Favorites'
_C='left'
_B='Songs'
_A='top'
try:from tkinter import Toplevel,ttk;from time import sleep
except ImportError as err:exit(err)
class SongMenu(Toplevel):
	def __init__(A,parent):B=parent;super().__init__(B);A.parent=B;A.playlists=B.settings['playlists'];A.icons=B.icons;A.playlist_menu=B.menu_playlist;A.playlist_panels={};A.animation=None;A.song='';A.disabled_playlists=[];A.withdraw();A.overrideredirect(True);A.protocol('WM_DELETE_WINDOW',A.hide());A.bind('<FocusOut>',lambda _:A.hide());A.configure(background=B['background']);A.init_ui()
	def init_ui(A):
		ttk.Button(A,image=A.icons['plus'],text='Add playlist',compound=_C,command=A.add_playlist).pack(side=_A,fill='x',padx=5,pady=(5,5));A.playlist_panel=ttk.Frame(A)
		for B in A.playlists:
			if B!=_D:A.playlist_panels[B]=ttk.Button(A.playlist_panel,image=A.icons[_E][0],text=A.playlists[B]['Name'],compound=_C,command=lambda:A.add_to_playlist(B));A.playlist_panels[B].pack(side=_A,fill='x',padx=5,pady=(0,5))
		A.playlist_panel.pack(side=_A,fill='both');A.delete_button=ttk.Button(A,image=A.icons['delete'],text='Remove',compound=_C,command=A.remove_from_playlist);A.delete_button.pack(side=_A,fill='x',padx=5,pady=(5,5))
	def show(A,song):
		A.song=song;A.update_options();A.set_position()
		if not A.animation:A.deiconify();A.animation=A.after(0,A.animate)
		A.focus_set()
	def hide(A):A.withdraw()
	def update_options(A):
		D='!disabled';C='disabled';E=A.playlist_menu.get()
		for B in A.playlists:
			if B!=_D:
				if A.song in A.playlists[B][_B]:A.playlist_panels[B].state([C]);A.disabled_playlists.append(B)
				elif B in A.disabled_playlists:A.playlist_panels[B].state([D]);A.disabled_playlists.remove(B)
		if E==_D:A.delete_button.state([C])
		else:A.delete_button.state([D])
	def set_position(A):
		C=A.parent.winfo_pointerxy();E=A.winfo_width(),A.winfo_height();D=A.parent.winfo_containing(C[0],C[1])
		if D:
			B=D.winfo_rootx(),D.winfo_rooty()
			if B[0]>=A.winfo_screenwidth()-E[0]-45:A.geometry(f"+{B[0]-E[0]-10}+{B[1]-6}")
			else:A.geometry(f"+{B[0]+45}+{B[1]-6}")
		else:A.geometry(f"+{C[0]}+{C[1]}")
	def animate(A):
		B=A.winfo_width(),A.winfo_height();C=len(A.playlists)+1;D=5
		for E in range(int(B[1]/C/D)):sleep(0.0001);A.geometry(f"{B[0]}x{E*C*D}");A.update()
		A.geometry('');A.animation=None
	def append(A,playlist):B=playlist;A.playlist_panels[B]=ttk.Button(A.playlist_panel,image=A.icons[_E][0],text=A.playlists[B]['Name'],compound=_C,command=lambda:A.add_to_playlist(B));A.playlist_panels[B].pack(side=_A,fill='x',padx=5,pady=(0,5))
	def remove(A,playlist):
		B=playlist
		if B in A.playlist_panels:A.playlist_panels[B].destroy();del A.playlist_panels[B]
		if B in A.disabled_playlists:A.disabled_playlists.remove(B)
	def rename(A,playlist,name):A.playlist_panels[playlist]['text']=name
	def remove_from_playlist(A):
		B=A.playlist_menu.get()
		if B=='Library':A.parent.remove_song(A.song)
		elif B!=_D and B in A.playlists and A.song in A.playlists[B][_B]:
			A.playlists[B][_B].remove(A.song)
			if A.song in A.parent.songs:A.parent.songs.remove(A.song)
			if A.song in A.parent.song_panels:A.parent.song_panels[A.song].pack_forget()
			if not A.playlists[B][_B]:A.parent.no_songs.pack(side=_A,fill='x',pady=5,padx=10)
		A.hide()
	def add_to_playlist(A,playlist):
		B=playlist
		if B in A.playlists and A.song in A.parent.library and not A.song in A.playlists[B][_B]:A.playlists[B][_B].append(A.song)
		A.hide()
	def add_playlist(A):A.parent.add_playlist();A.add_to_playlist(list(A.playlists.keys())[-1])