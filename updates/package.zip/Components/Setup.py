_W='second.TFrame'
_V='folder'
_U='delete'
_T='checkmark'
_S='plus'
_R='Vertical.TScrollbar'
_Q='TRadiobutton'
_P='TButton'
_O='brush'
_N='System'
_M='folders'
_L='third.TLabel'
_K='value'
_J='arrow'
_I='second.TLabel'
_H=False
_G='second.TButton'
_F='right'
_E='x'
_D='left'
_C=True
_B='top'
_A='center'
try:from tkinter import Toplevel,ttk,Canvas,StringVar,BooleanVar,PhotoImage;from tkinter.filedialog import askdirectory,askopenfilename;from os.path import basename,abspath;from time import sleep;from threading import Thread;from json import load;from json.decoder import JSONDecodeError
except ImportError as err:exit(err)
class SSetup(Toplevel):
	def __init__(A,parent,settings):B=parent;super().__init__(B);A.settings=settings;A.parent=B;A.pages=5;A.withdraw();A.geometry(f"500x620+{int(A.winfo_x()+(A.winfo_screenwidth()/2-250))}+{int(A.winfo_y()+(A.winfo_screenheight()/2-310))}");A.resizable(_H,_H);A.title('Sounder configurator');A.protocol('WM_DELETE_WINDOW',A.exit_app);A.init_layout();A.load_icons();A.apply_theme();A.init_ui();A.deiconify()
	def exit_app(A):A.quit();A.destroy()
	def init_layout(B):D='children';C='nswe';A='sticky';B.layout=ttk.Style();B.layout.theme_use('clam');B.layout.layout(_P,[('Button.padding',{A:C,D:[('Button.label',{A:C})]})]);B.layout.layout(_Q,[('Radiobutton.padding',{A:C,D:[('Radiobutton.label',{A:C})]})]);B.layout.layout(_R,[('Vertical.Scrollbar.trough',{D:[('Vertical.Scrollbar.thumb',{'expand':'1',A:C})],A:'ns'})])
	def init_ui(A):U='Next';T='Dark';S='Light';R='<Configure>';Q='both';G='bottom';A.theme=StringVar(value=_N);A.updates=BooleanVar(value=_C);C=ttk.Frame(A);C.pack(side=_B,fill=Q,expand=_C);A.progress_bar=ttk.Progressbar(A,maximum=A.pages*100,value=0);A.progress_bar.pack(side=G,fill=_E);J=ttk.Frame(C);K=ttk.Frame(J);ttk.Label(K,text='Welcome to Sounder5!',style=_I).pack(side=_B,pady=10,anchor=_A);ttk.Button(K,text='Start listening!',image=A.icons[_J][1],compound=_F,style=_G,command=lambda:A.next_page(H)).pack(side=_B,pady=10,anchor=_A);K.pack(anchor=_A,padx=10,pady=10,expand=_C);J.place(x=0,y=0,relwidth=1,relheight=1);H=ttk.Frame(C);ttk.Label(H,text='Import settings!',style=_I).pack(side=_B,anchor=_A,pady=(10,0));ttk.Label(H,text='Import old settings or set up as new!',style=_L).pack(side=_B,anchor=_A);L=ttk.Frame(H);ttk.Button(L,text='Set up as new',image=A.icons[_J][1],compound=_F,style=_G,command=lambda:A.next_page(D)).pack(side=G,pady=10,anchor=_A,fill=_E);ttk.Button(L,text='Choose a settings file',image=A.icons[_S],compound=_F,style=_G,command=A.import_settings).pack(side=G,pady=10,anchor=_A,fill=_E);L.pack(anchor=_A,padx=10,pady=10,expand=_C);H.place(x=0,y=0,relwidth=1,relheight=1);D=ttk.Frame(C);M=ttk.Scrollbar(D);M.pack(side=_F,fill='y');ttk.Label(D,text="Let's start with music!",style=_I).pack(side=_B,anchor=_A,pady=(10,0));ttk.Label(D,text='Show us where you store your music.',style=_L).pack(side=_B,anchor=_A);B=Canvas(D,background=A['background'],bd=0,highlightthickness=0,yscrollcommand=M.set,takefocus=_H);M.configure(command=B.yview);A.folder_panels=ttk.Frame(B);A.folder_panels.bind(R,lambda _:B.configure(scrollregion=B.bbox('all')));V=B.create_window((0,0),window=A.folder_panels,anchor='nw');B.bind(R,lambda _:B.itemconfigure(V,width=B.winfo_width(),height=0));B.pack(side=_B,padx=10,pady=10,anchor=_A,fill=Q);N=ttk.Frame(D);ttk.Button(N,text='Add folder',image=A.icons[_S],compound=_D,style=_G,command=A.add_folder).pack(side=_D,pady=5,padx=(10,25));A.folder_button=ttk.Button(N,text='Skip',image=A.icons[_J][1],compound=_F,style=_G,command=lambda:A.next_page(E));A.folder_button.pack(side=_F,pady=5,padx=(25,10));N.pack(side=G,pady=5);D.place(x=0,y=0,relwidth=1,relheight=1);E=ttk.Frame(C);ttk.Label(E,text='Theme!',style=_I).pack(side=_B,anchor=_A,pady=(10,0));ttk.Label(E,text='Shine bright like a star or be dark like a boss!',style=_L).pack(side=_B,anchor=_A);I=ttk.Frame(E);ttk.Radiobutton(I,image=A.icons[_O],text=S,compound=_D,variable=A.theme,value=S,command=A.change_theme).pack(side=_B,fill=_E,padx=10,pady=5,ipadx=45);ttk.Radiobutton(I,image=A.icons[_O],text=T,compound=_D,variable=A.theme,value=T,command=A.change_theme).pack(side=_B,fill=_E,padx=10,pady=5,ipadx=45);ttk.Radiobutton(I,image=A.icons[_O],text=_N,compound=_D,variable=A.theme,value=_N,command=A.change_theme).pack(side=_B,fill=_E,padx=10,pady=5,ipadx=45);I.pack(anchor=_A,padx=10,pady=10,expand=_C);ttk.Button(E,text=U,image=A.icons[_J][1],compound=_F,style=_G,command=lambda:A.next_page(F)).pack(side=G,pady=10,anchor=_A);E.place(x=0,y=0,relwidth=1,relheight=1);F=ttk.Frame(C);ttk.Label(F,text='Updates!',style=_I).pack(side=_B,anchor=_A,pady=(10,0));ttk.Label(F,text="That's right, everybody likes updates!",style=_L).pack(side=_B,anchor=_A);O=ttk.Frame(F);ttk.Radiobutton(O,image=A.icons[_T],text='Yes, check for updates!',compound=_D,value=_C,variable=A.updates,command=A.change_updates).pack(side=_B,fill=_E,padx=10,pady=5,ipadx=45);ttk.Radiobutton(O,image=A.icons[_U],text='No :(',compound=_D,value=_H,variable=A.updates,command=A.change_updates).pack(side=_B,fill=_E,padx=10,pady=5,ipadx=45);O.pack(anchor=_A,padx=10,pady=10,expand=_C);ttk.Button(F,text=U,image=A.icons[_J][1],compound=_F,style=_G,command=lambda:A.next_page(A.final_panel)).pack(side=G,pady=10,anchor=_A);F.place(x=0,y=0,relwidth=1,relheight=1);A.final_panel=ttk.Frame(C);P=ttk.Frame(A.final_panel);ttk.Label(P,text="That's all!",style=_I).pack(side=_B,pady=10,anchor=_A);ttk.Button(P,text='Finish',image=A.icons[_T],compound=_D,style=_G,command=A.exit_app).pack(side=_B,pady=10,anchor=_A);P.pack(anchor=_A,padx=10,pady=10,expand=_C);A.final_panel.place(x=0,y=0,relwidth=1,relheight=1);J.lift()
	def load_icons(A):B='logo';A.icons={_J:(PhotoImage(file='Resources\\\\Icons\\\\Configurator\\\\left.png'),PhotoImage(file='Resources\\\\Icons\\\\Configurator\\\\right.png')),B:PhotoImage(file='Resources\\\\Icons\\\\Configurator\\\\setup.png'),_S:PhotoImage(file='Resources\\\\Icons\\\\Configurator\\\\plus.png'),_V:PhotoImage(file='Resources\\\\Icons\\\\Configurator\\\\music_folder.png'),_U:PhotoImage(file='Resources\\\\Icons\\\\Configurator\\\\delete.png'),_O:PhotoImage(file='Resources\\\\Icons\\\\Configurator\\\\brush.png'),_T:PhotoImage(file='Resources\\\\Icons\\\\Configurator\\\\checkmark.png')};A.iconphoto(_H,A.icons[B])
	def apply_theme(B):J='selected';I='active';H='!disabled';G='pressed';F='#fff';E='catamaran 13 bold';D='flat';C='#111';A='#212121';B.configure(background=A);B.layout.configure('TFrame',background=A);B.layout.configure(_W,background=C);B.layout.configure('TLabel',background=C,relief=D,font=E,foreground=F);B.layout.configure(_I,background=A,font='catamaran 30 bold',anchor=_A);B.layout.configure(_L,background=A);B.layout.configure(_Q,background=A,relief=D,font=E,foreground=F,anchor='w',padding=10,width=12);B.layout.map(_Q,background=[(G,H,C),(I,C),(J,C)]);B.layout.configure(_P,background=C,relief=D,font=E,foreground=F,anchor='w');B.layout.map(_P,background=[(G,H,A),(I,A),(J,A)]);B.layout.configure(_G,anchor=_A);B.layout.configure(_R,gripcount=0,relief=D,background=A,darkcolor=A,lightcolor=A,troughcolor=A,bordercolor=A);B.layout.map(_R,background=[(G,H,C),('disabled',A),(I,C),('!active',C)]);B.layout.configure('Horizontal.TProgressbar',foreground=C,background=C,lightcolor=C,darkcolor=C,bordercolor=A,troughcolor=A)
	def add_folder(B):
		A=askdirectory()
		if A and not A in B.settings[_M]:A=abspath(A);B.settings[_M].append(A);C=ttk.Frame(B.folder_panels,style=_W);D=ttk.Label(C,image=B.icons[_V],text=basename(A),compound=_D);D.pack(side=_D,anchor=_A,fill='y',pady=10,padx=10);ttk.Button(C,image=B.icons[_U],takefocus=_H,command=lambda:B.remove_folder(C,A)).pack(side=_F,padx=10,anchor=_A);C.bind('<Leave>',lambda _:D.configure(text=basename(A)));C.bind('<Enter>',lambda _:D.configure(text=A));C.pack(side=_B,fill=_E,pady=5,padx=10);B.folder_button.configure(text='Continue')
	def remove_folder(A,panel,folder):
		B=folder
		if B in A.settings[_M]:
			A.settings[_M].remove(B);panel.destroy()
			if len(A.settings[_M])==0:A.folder_button.configure(text='Skip')
	def change_theme(A):
		B=A.theme.get()
		if B!=_N:A.settings['use_system_theme']=_H;A.settings['theme']=B
	def change_updates(A):A.settings['updates']=A.updates.get()
	def next_page(A,page):Thread(target=A.update_progress,daemon=_C).start();page.lift()
	def update_progress(A):
		for B in range(10):A.progress_bar[_K]+=10;sleep(0.01)
		if A.progress_bar[_K]==A.pages*100:A.progress_bar[_K]=0
	def animate_progress(A,value):
		for B in range(int(value/10)):A.progress_bar[_K]+=10;sleep(0.001)
		if A.progress_bar[_K]==A.pages*100:A.progress_bar[_K]=0
	def import_settings(A):
		B=askopenfilename(title='Open a settings file',initialdir='/',filetypes=(('Sounder settings files','*.json'),))
		if B:
			with open(B,'r')as C:
				try:A.settings.update(load(C));Thread(target=A.animate_progress,args=(400,),daemon=_C).start();A.final_panel.lift()
				except JSONDecodeError:pass