_A='third.TButton'
from tkinter import Toplevel,ttk,StringVar,PhotoImage
from typing import Callable
class ComboBox(ttk.Frame):
	def __init__(A,parent,values,default_value=0,image=None,command=None):C=values;B=parent;super().__init__(B);A.parent=B;A.values=C;A.command=command;A.value=StringVar(value=C[default_value]);ttk.Button(A,image=image,textvariable=A.value,style=_A,compound='right',command=A.toggle_panel).pack(anchor='c');A.init_window()
	def init_window(A):
		A.window=Toplevel(A.parent);A.window.withdraw();A.window.overrideredirect(True);A.window.bind('<FocusOut>',lambda _:A.hide());A.window.protocol('WM_DELETE_WINDOW',lambda _:A.hide())
		for B in A.values:A.add_option(B)
	def add_option(A,option):B=option;ttk.Button(A.window,text=B,command=lambda:A.select_option(B),style=_A).pack(anchor='c',fill='x')
	def toggle_panel(A):
		A.window.deiconify();B=A.parent.winfo_pointerxy();C=A.parent.winfo_containing(B[0],B[1])
		if C:D=C.winfo_rootx(),C.winfo_rooty();A.window.geometry(f"{C.winfo_width()}x{len(A.values)*38}+{D[0]}+{D[1]+38}")
		else:A.window.geometry('');A.window.geometry(f"+{B[0]}+{B[1]}")
		A.window.focus_set()
	def select_option(A,option):B=option;A.value.set(B);A.window.withdraw();A.command(B)
	def hide(A):A.window.after(10,A.window.withdraw)